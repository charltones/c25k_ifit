#!/bin/bash
cd iFit/Tread
